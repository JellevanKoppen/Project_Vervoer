<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Museum Informatica"/>
    <meta name="keywords" content="INF PO"/>
    <meta name="author" content="Jelle van Koppen; Joey Kouwenhoven; Ard de Bruijn; Joost van den Berg; Michael Nederlof; Stefan van der Berg"/>
    <meta name="versie" content="0.5"/>
    <link rel="shortcut icon" href="./images/pictogram.png">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <header id="#">
    <div class="header">
      <a href="index.html" alt="Home Menu"><img src="./images/logo.png" class="logo" alt="Museum Logo"></a>
      <h1 class="titel">Welkom bij de Oude Doos!</h1>
      <h2 class="ondertitel">Het Informatica museum in lokaal 119</h2>
    </div>
      <div class="menu-wrap">
      	<nav class="menu">
      		<ul class="clearfix">
      			<li class="current-item"><a href="Index.html">Home</a></li>
      			<li>
      				<a href="deadend.html">Items <span class="arrow">&#9660;</span></a>
      				<ul class="sub-menu">
      					<li><a href="deadend.html">Item van de week</a></li>
      					<li><a href="search.html">Zoeken</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      				</ul>
      			</li>
      			<li><a href="deadend.html">Agenda</a></li>
      			<li><a href="deadend.html">Contact</a></li>
      			<li><a href="login.php">Inloggen</a></li>
      		</ul>
      	</nav>
      </div>
      <div class="topmenu-wrap">
      		<ul class="topnav">
            <li class="icon">
              <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
            </li>
      			<li class="current-side-item"><a href="Index.html">Home</a></li>
      			<li class="sub-list">
              <input type="checkbox" id="submenu_toggle">
      				<label id="sub_label" for="submenu_toggle">Items <span class="arrow_top">&#9660;</span></label>
      				<ul class="top-sub">
                <li><a href="deadend.html">Overzicht</a></li>
      					<li><a href="deadend.html">Item van de week</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      				</ul>
      			</li>
      			<li><a href="deadend.html">Agenda</a></li>
      			<li><a href="deadend.html">Contact</a></li>
      			<li><a href="login.php">Inloggen</a></li>
          </ul>
        </div>
    </header>
    <article class="">
      <p>Lege pagina</p>
    </article>
    <footer>
      <p class="fnormaal">
        &copy; Copyright Jelle van Koppen, Joey Kouwenhoven, Ard de Bruijn, Joost van den Berg, <br /> Michael Nederlof, Stefan van der Berg | Klas H5IN6 | Groep 01
      </p>
      <p class="fsmall" >
        &copy; J.v.Koppen, J.Kouwenhoven, A.d.Bruijn, J.v.d.Berg, <br /> M.Nederlof, S.v.d.Berg
      </p>
      <a href="https://twitter.com/csg_dewillem" target="_blank" class="link"><img src="./images/twitter.png" style="width:25px;vertical-align:middle"></a>
      <a href="https://nl-nl.facebook.com/dewillem.nl/" target="_blank" class="link"><img src="./images/willem.png" style="width:25px;vertical-align:middle"></a>
      <a href="https://www.instagram.com/explore/locations/256931288/" target="_blank" class="link"><img src="./images/instagram.png" style="width:25px;vertical-align:middle"></a>
      <a href="#" class="link2">Terug naar boven &uarr;</a>
    </footer>
  </body>
</html>
