<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Museum Informatica"/>
    <meta name="keywords" content="INF PO"/>
    <meta name="author" content="Jelle van Koppen; Joey Kouwenhoven; Ard de Bruijn; Joost van den Berg; Michael Nederlof; Stefan van der Berg"/>
    <link rel="shortcut icon" href="./images/pictogram.png">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
  </head>
  <body>
    <header id="#">
    <div class="header">
      <a href="index.html" alt="Home Menu"><img src="./images/logo.png" class="logo" alt="Museum Logo"></a>
      <h1 class="titel">Welkom bij de Oude Doos!</h1>
      <h2 class="ondertitel">Registratie</h2>
    </div>
      <div class="menu-wrap">
      	<nav class="menu">
      		<ul class="clearfix">
      			<li><a href="Index.html">Home</a></li>
      			<li>
      				<a href="deadend.html">Items <span class="arrow">&#9660;</span></a>
      				<ul class="sub-menu">
      					<li><a href="deadend.html">Item van de week</a></li>
      					<li><a href="search.html">Zoeken</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      				</ul>
      			</li>
      			<li><a href="deadend.html">Agenda</a></li>
      			<li><a href="deadend.html">Contact</a></li>
      			<li class="current-item"><a href="login.php">Inloggen</a></li>
      		</ul>
      	</nav>
      </div>
      <div class="topmenu-wrap">
      		<ul class="topnav">
            <li class="icon">
              <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
            </li>
      			<li class="current-side-item"><a href="Index.html">Home</a></li>
      			<li class="sub-list">
              <input type="checkbox" id="submenu_toggle">
      				<label id="sub_label" for="submenu_toggle">Items <span class="arrow_top">&#9660;</span></label>
      				<ul class="top-sub">
                <li><a href="deadend.html">Overzicht</a></li>
      					<li><a href="deadend.html">Item van de week</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      				</ul>
      			</li>
      			<li><a href="deadend.html">Agenda</a></li>
      			<li><a href="deadend.html">Contact</a></li>
      			<li><a href="deadend.html">Inloggen</a></li>
          </ul>
        </div>
    </header>
    <?php
    //include 'Dbconnect.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST"){
      if (empty($_POST['naam'])){
        echo "Waarden zijn leeg!";
      } else {
        $GEBOORTEDATUM = $_POST["dag"] + $_POST["maand"] + $_POST["jaar"];
        echo $GEBOORTEDATUM;
        $VN=$_POST["voornaam"];
        $AN=$_POST["achternaam"];
        $EMAIL=$_POST["email"];
        $GENDER=$_POST["gender"];
        $GD=$GEBOORTEDATUM;
        $STAD=$_POST["stad"];

        $sql="INSERT INTO gebruikers (voornaam,achternaam,email,gender,geboortedatum,woonplaats) VALUES('".$VN."','".$AN."','".$EMAIL."','".$GENDER."','".$GD."','".$STAD."')";

        $result = mysqli_query($conn, $sql);

        if ($result->num_rows>0){
          echo "Succes!";
          } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
      mysql_close($conn);
    }

    ?>
    <article class="registratie">
      <form method="post" action="<?php htmlspecialchars($_SERVER['PHP_SELF']); ?>">

      <table class="registratietabel">

      <!----- First Name ---------------------------------------------------------->
      <tr>
      <td class="links">Voornaam:</td>
      <td><input type="text" name="voornaam" maxlength="30"/>
      (max 30 tekens a-z en A-Z)
      </td>
      </tr>

      <!----- Last Name ---------------------------------------------------------->
      <tr>
      <td class="links">Achternaam:</td>
      <td><input type="text" name="achternaam" maxlength="30"/>
      (max 30 tekens a-z en A-Z)
      </td>
      </tr>

      <!----- Date Of Birth -------------------------------------------------------->
      <tr>
      <td class="links">Geboortedatum:</td>

      <td>
      <select name="dag" id="Birthday_day">
      <option value="-1">Dag:</option>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>

      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
      <option value="7">7</option>
      <option value="8">8</option>
      <option value="9">9</option>
      <option value="10">10</option>
      <option value="11">11</option>
      <option value="12">12</option>

      <option value="13">13</option>
      <option value="14">14</option>
      <option value="15">15</option>
      <option value="16">16</option>
      <option value="17">17</option>
      <option value="18">18</option>
      <option value="19">19</option>
      <option value="20">20</option>
      <option value="21">21</option>

      <option value="22">22</option>
      <option value="23">23</option>
      <option value="24">24</option>
      <option value="25">25</option>
      <option value="26">26</option>
      <option value="27">27</option>
      <option value="28">28</option>
      <option value="29">29</option>
      <option value="30">30</option>

      <option value="31">31</option>
      </select>

      <select id="Birthday_Month" name="maand">
      <option value="-1">Maand:</option>
      <option value="January">Jan</option>
      <option value="February">Feb</option>
      <option value="March">Mar</option>
      <option value="April">Apr</option>
      <option value="May">Mei</option>
      <option value="June">Jun</option>
      <option value="July">Jul</option>
      <option value="August">Aug</option>
      <option value="September">Sep</option>
      <option value="October">Okt</option>
      <option value="November">Nov</option>
      <option value="December">Dec</option>
      </select>

      <select name="jaar" id="Birthday_Year">

      <option value="-1">Jaar:</option>
      <option value="2012">2012</option>
      <option value="2011">2011</option>
      <option value="2010">2010</option>
      <option value="2009">2009</option>
      <option value="2008">2008</option>
      <option value="2007">2007</option>
      <option value="2006">2006</option>
      <option value="2005">2005</option>
      <option value="2004">2004</option>
      <option value="2003">2003</option>
      <option value="2002">2002</option>
      <option value="2001">2001</option>
      <option value="2000">2000</option>

      <option value="1999">1999</option>
      <option value="1998">1998</option>
      <option value="1997">1997</option>
      <option value="1996">1996</option>
      <option value="1995">1995</option>
      <option value="1994">1994</option>
      <option value="1993">1993</option>
      <option value="1992">1992</option>
      <option value="1991">1991</option>
      <option value="1990">1990</option>

      <option value="1989">1989</option>
      <option value="1988">1988</option>
      <option value="1987">1987</option>
      <option value="1986">1986</option>
      <option value="1985">1985</option>
      <option value="1984">1984</option>
      <option value="1983">1983</option>
      <option value="1982">1982</option>
      <option value="1981">1981</option>
      <option value="1980">1980</option>
      </select>
      </td>
      </tr>

      <!----- Email Id ---------------------------------------------------------->
      <tr>
      <td class="links">Email adres:</td>
      <td><input type="text" name="email" maxlength="100" /></td>
      </tr>



      <!----- Gender ----------------------------------------------------------->
      <tr>
      <td class="links">Geslacht:</td>
      <td>
      Man <input type="radio" name="Gender" value="Male" />
      Vrouw <input type="radio" name="Gender" value="Female" />
      Onzijdig <input type="radio" name="Gender" value="Onzijdig" />
      </td>
      </tr>



      <!----- City ---------------------------------------------------------->
      <tr>
      <td class="links">Woonplaats:</td>
      <td><input type="text" name="stad" maxlength="30" />
      (max 30 tekens a-z en A-Z)
      </td>
      </tr>


      <!----- Submit and Reset ------------------------------------------------->
      <tr>
      <td colspan="2" align="center">
      <input type="reset" value="Reset">
      <input type="submit" value="Volgende">
      </td>
      </tr>
      </table>

      </form>
    </article>
    <footer>
      <p class="fnormaal">
        &copy; Copyright Jelle van Koppen, Joey Kouwenhoven, Ard de Bruijn, Joost van den Berg, <br /> Michael Nederlof, Stefan van der Berg | Klas H5IN6 | Groep 01
      </p>
      <p class="fsmall" >
        &copy; J.v.Koppen, J.Kouwenhoven, A.d.Bruijn, J.v.d.Berg, <br /> M.Nederlof, S.v.d.Berg
      </p>
      <a href="https://twitter.com/csg_dewillem" target="_blank" class="link"><img src="./images/twitter.png" style="width:25px;vertical-align:middle"></a>
      <a href="https://nl-nl.facebook.com/dewillem.nl/" target="_blank" class="link"><img src="./images/willem.png" style="width:25px;vertical-align:middle"></a>
      <a href="https://www.instagram.com/explore/locations/256931288/" target="_blank" class="link"><img src="./images/instagram.png" style="width:25px;vertical-align:middle"></a>
      <a href="#" class="link2">Terug naar boven &uarr;</a>
    </footer>
  </body>
</html>
