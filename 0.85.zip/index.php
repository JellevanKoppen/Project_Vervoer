<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Museum Informatica"/>
    <meta name="keywords" content="INF PO"/>
    <meta name="author" content="Jelle van Koppen; Joey Kouwenhoven; Ard de Bruijn; Joost van den Berg; Michael Nederlof; Stefan van der Berg"/>
    <meta name="versie" content="0.5"/>
    <link rel="shortcut icon" href="./images/pictogram.png">
    <link href="stylesheet.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
    <script type="text/javascript">
      function dropdown() {
        var ele = document.getElementById("hide");
        var top = document.getElementById("shown");
        var page = document.getElementById("frontpage");
        var width = $( window ).width();
        if(ele.style.display == "block" && width > 420 && width < 641){
          top.style.width = "45px";
          ele.style.display = "none";
          page.style.width = "calc(100% - 55px)";
          page.style.marginLeft = "45px";
        } else if(ele.style.display == "none" && width < 421){
          ele.style.display = "block";
          top.style.width = "100px";
          page.style.width = "calc(100% - 110px)";
          page.style.marginLeft = "100px";

        } else if(ele.style.display == "block" && width < 421){
            ele.style.display = "none";
            top.style.width = "45px";
            page.style.width = "calc(100% - 55px)";
            page.style.marginLeft = "45px";
        } else {
          ele.style.display = "block";
          top.style.width = "165px";
          page.style.width = "calc(100% - 175px)";
          page.style.marginLeft = "165px";
        }
      }

    </script>
  </head>
  <body>
    <header id="#">
    <div class="header">
      <a href="index.php" alt="Home Menu"><img src="./images/logo.png" class="logo" alt="Museum Logo"></a>
      <h1 class="titel">Welkom bij de Oude Doos!</h1>
      <h2 class="ondertitel">Het Informatica museum in lokaal 119</h2>
    </div>
      <div class="menu-wrap">
      	<nav class="menu">
      		<ul class="clearfix">
      			<li class="current-item"><a href="Index.php">Home</a></li>
      			<li>
      				<a href="items.html">Items <span class="arrow">&#9660;</span></a>
      				<ul class="sub-menu">
      					<li><a href="deadend.html">Item van de week</a></li>
      					<li><a href="search.html">Zoeken</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      				</ul>
      			</li>
      			<li><a href="deadend.html">Agenda</a></li>
      			<li><a href="deadend.html">Contact</a></li>
      			<li><a href="login.php">Inloggen</a></li>
      		</ul>
      	</nav>
      </div>
      <div class="topmenu-wrap">
      		<ul id="shown" class="topnav" style="width: 45px;">
              <li class="icon">
                <a href="javascript:void(0);" onclick="dropdown()">&#9776;</a>
              </li>
            <div id="hide" style="display: none">
      			<li class="current-side-item"><a href="Index.php">Home</a></li>
      			<li class="sub-list">
              <input type="checkbox" id="submenu_toggle">
      				<label id="sub_label" for="submenu_toggle">Items <span class="arrow_top">&#9660;</span></label>
      				<ul class="top-sub">
                <li><a href="items.html">Items</a></li>
      					<li><a href="deadend.html">Item van de week</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      					<li><a href="deadend.html">...</a></li>
      				</ul>
      			</li>
      			<li><a href="deadend.html">Agenda</a></li>
      			<li><a href="deadend.html">Contact</a></li>
      			<li><a href="login.php">Inloggen</a></li>
          </ul>
        </div>
        </div>
    </header>
    <article class="frontpage" id="frontpage">
      <h3>Welkom:</h3>
      <div class="afscheiding"></div>
      <article class="links">
       <p>
       <?php
       function translateDay(){
         $dag = date('l');
         $Engels = [
          0 => "Monday",
          1 => "Tuesday",
          2 => "Wednesday",
          3 => "Thursday",
          4 => "Friday",
          5 => "Saturday",
          6 => "Sunday",
         ];
         $Nederlands = [
           0 => "Maandag",
           1 => "Dinsdag",
           2 => "Woensdag",
           3 => "Donderdag",
           4 => "Vrijdag",
           5 => "Zaterdag",
           6 => "Zondag",
          ];

         for ($x = 0; $x <= 7; $x++){
           if ($dag == $Engels[$x]){
             $dag = $Nederlands[$x];
             return $dag;
           }
         }
       }
       function translateMonth(){
         $ma = date("m");
         $Maand = [
           "01" => "Januari",
           "02" => "Februari",
           "03" => "Maart",
           "04" => "April",
           "05" => "Mei",
           "06" => "Juni",
           "07" => "Juli",
           "08" => "Augustus",
           "09" => "September",
           "10" => "Oktober",
           "11" => "November",
           "12" => "December",
         ];
         $m = $Maand[$ma];
         return $m;
       }

       $vandaag = translateDay();
       $maand = translateMonth();

       echo "Het is vandaag: ". $vandaag. ", " . date("d ") . $maand . date(" Y") . "<br> <br>";
       ?>
      </p>
      </article>
      <div class="small_afscheiding"></div>
      <article class="midden">
        <p>Dit is een regel midden</p>
      </article>
      <div class="small_afscheiding"></div>
      <article class="rechts">
        <p>Dit is een regel rechts</p>
      </article>
    </article>
    <footer>
      <p class="fnormaal">
        &copy; Copyright Jelle van Koppen, Joey Kouwenhoven, Ard de Bruijn, Joost van den Berg, <br /> Michael Nederlof, Stefan van der Berg | Klas H5IN6 | Groep 01
      </p>
      <p class="fsmall" >
        &copy; J.v.Koppen, J.Kouwenhoven, A.d.Bruijn, J.v.d.Berg, <br /> M.Nederlof, S.v.d.Berg
      </p>
      <a href="https://twitter.com/csg_dewillem" target="_blank" class="link"><img src="./images/twitter.png" style="width:25px;vertical-align:middle"></a>
      <a href="https://nl-nl.facebook.com/dewillem.nl/" target="_blank" class="link"><img src="./images/willem.png" style="width:25px;vertical-align:middle"></a>
      <a href="https://www.instagram.com/explore/locations/256931288/" target="_blank" class="link"><img src="./images/instagram.png" style="width:25px;vertical-align:middle"></a>
      <a href="#" class="link2">Terug naar boven &uarr;</a>
    </footer>
  </body>
</html>
